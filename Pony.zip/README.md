<h1>Pony</h1>
HaXe open-cross-library
Ready for Haxe3 and HUGS
<p><small>v0.1.5/small></p>
<p><small><a href="http://axgord.github.com/Pony/docs">Reference book</a></small></p>

<h2>Installation</h2>
<pre>haxelib install Pony</pre>

<h2>ToDo</h2>
Write documentation.

<h2>Tests</h2>
<pre>
Tests: 31  Passed: 31  Failed: 0 Errors: 0 Ignored: 0 Time: 0.008
</pre>